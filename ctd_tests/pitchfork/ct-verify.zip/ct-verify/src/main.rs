use std::path::Path;
use pitchfork::Project;
use pitchfork::*;
use pitchfork::hooks::return_secret;
fn main() {
    if let Ok(project) = Project::from_bc_path(&Path::new("file.bc")){
        let mut c = Config::default();
        c.loop_bound = 24;
        c.function_hooks.add("llvm.x86.avx2.pshuf.b", &return_secret);
        c.function_hooks.add("llvm.x86.ssse3.pshuf.b.128",&return_secret);
        println!("{}", check_for_ct_violation(
            "ct_decode",
            &project,
            Some(vec![AbstractData::pub_pointer_to(AbstractData::_struct("Context", vec![
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::secret(),
                AbstractData::pub_pointer_to(AbstractData::array_of(AbstractData::secret(), 16))

            ])), AbstractData::default()]),
            &StructDescriptions::new(),
            c,
            &PitchforkConfig::default(),
        ));
    }else {
        println!("please rename the bitcode fifle as file.bc")
    }

}
